
<footer class="footer text-right">
    2019 © Developed by <a href="http://skoder.co" target="_blank">skoder.co</a>
</footer>
