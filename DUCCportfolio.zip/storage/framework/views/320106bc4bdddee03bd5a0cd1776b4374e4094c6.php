<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="page-title-box">
                    <h4 class="page-title">Edit Member</h4>
                    <ol class="breadcrumb p-0 m-0">
                        <li>
                            <a href="#">Admin</a>
                        </li>
                        <li>
                            <a href="#">Member </a>
                        </li>
                        <li class="active">
                            Edit Member
                        </li>
                    </ol>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-10">
                <form action="<?php echo e(route('admin.member.update',$member->id)); ?>"  class="form-horizontal" name="category" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="form-group">
                        <label class="col-md-2 control-label"> Name</label>
                        <div class="col-md-10">
                            <input type="text" class="form-control" value="<?php echo e($member->name); ?>" name="name" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-2 control-label"> Phone</label>
                        <div class="col-md-10">
                            <input type="text" class="form-control" value="<?php echo e($member->phone); ?>" name="phone" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-2 control-label"> Blood Group</label>
                        <div class="col-md-10">
                           <select class="form-control" name="blood_group">

                               <option value="<?php echo e($member->blood_group); ?>"><?php echo e($member->blood_group); ?></option>
                               <option value="A+">A+</option>
                               <option value="A-">A-</option>
                               <option value="B+">B+</option>
                               <option value="B-">B-</option>
                               <option value="AB+">AB+</option>
                               <option value="AB-">AB-</option>
                               <option value="O-">O-</option>
                               <option value="O-">O-</option>
                           </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2 control-label"> Current Address</label>
                        <div class="col-md-10">
                            <input type="text" class="form-control" value="<?php echo e($member->current_address); ?>" name="current_address" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-2 control-label"> Permanent Address </label>
                        <div class="col-md-10">
                            <input type="text" class="form-control" value="<?php echo e($member->permanent_address); ?>" name="permanent_address" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2 control-label"> Home District </label>
                        <div class="col-md-10">
                            <input type="text" class="form-control" value="<?php echo e($member->home_district); ?>" name="home_district" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2 control-label"> Department </label>
                        <div class="col-md-10">
                            <input type="text" class="form-control" value="<?php echo e($member->department); ?>" name="department" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2 control-label"> Department Roll </label>
                        <div class="col-md-10">
                            <input type="text" class="form-control" value="<?php echo e($member->department_roll); ?>" name="department_roll" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2 control-label"> Designation </label>
                        <div class="col-md-10">
                            <input type="text" class="form-control" value="<?php echo e($member->designation); ?>" name="designation" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2 control-label"> Biography</label>
                        <div class="col-md-10">
                            <textarea class="form-control" rows="5" name="biography" required><?php echo e($member->biography); ?></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2 control-label"> Skills </label>
                        <div class="col-md-10">
                            <input type="text" class="form-control" value="<?php echo e($member->skills); ?>" name="skills" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-2 control-label"> Achievement </label>
                        <div class="col-md-10">
                            <input type="text" class="form-control" value="<?php echo e($member->achievement); ?>" name="achievement" required>
                        </div>
                    </div>



                    <div class="form-group">

                        <label class="col-md-2 control-label"> Image</label>
                        <div class="col-md-10">
                    <img height="100px" width="140px" src="<?php echo e(asset('member_images/'.$member->image)); ?>">
                            <input type="file" class="form-control" name="image" >
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-2 control-label">&nbsp;</label>
                        <div class="col-md-10">

                            <button type="submit" class="btn btn-custom waves-effect waves-light btn-md">
                                Submit
                            </button>
                        </div>
                    </div>

                </form>
            </div>


        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\setup\server\www\DUCCportfolio\resources\views/admin/edit_member.blade.php ENDPATH**/ ?>