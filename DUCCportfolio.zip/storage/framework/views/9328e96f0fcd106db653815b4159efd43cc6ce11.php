<?php $__env->startSection('title','Blog'); ?>

<?php $__env->startSection('content'); ?>

<!-- blog-details-area start -->
<section id="blog" class="blog-details-area ptb-140">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-xs-12">
                <div class="blog-details-wrap">
                    <div class="blog-details-img">
                        <img src="<?php echo e(asset('single_blog_images/'.$blogPost->image)); ?>" alt="">
                    </div>
                    <div class="blog-details-content">
                        <h3><?php echo e($blogPost->title); ?></h3>
                        <p> <?php echo e($blogPost->desc); ?></p>
                        <p> <?php echo app('translator')->getFromJson('header.Posted By'); ?>: <?php echo e($blogPost->posted_by); ?></p>
                        <p> <?php echo app('translator')->getFromJson('header.Date'); ?>: <?php echo e($blogPost->created_at->toFormattedDateString()); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12 col">
                <aside class="right-sidebar">

                    <div class="related-post mb-30">
                        <h3 class="sidebar-title"><?php echo app('translator')->getFromJson('header.Related Post'); ?></h3>
                        <ul>
                            <?php $__currentLoopData = $blogPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="related-post-items">
                                <div class="post-img">
                                    <img height="50px"  width="80px" src="<?php echo e(asset('blog_images/'.$blog->image)); ?>" alt="">
                                </div>
                                <div class="post-info">
                                    <a href="<?php echo e(route('single.blog',$blog->id)); ?>"><?php echo e($blog->title); ?></a>
                                    <p><?php echo e($blog->created_at->toFormattedDateString()); ?></p>
                                </div>
                            </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </aside>
            </div>
        </div>
    </div>
</section>
<!-- blog-details-area end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\setup\server\www\DUCCportfolio\resources\views/frontend/single_blog.blade.php ENDPATH**/ ?>