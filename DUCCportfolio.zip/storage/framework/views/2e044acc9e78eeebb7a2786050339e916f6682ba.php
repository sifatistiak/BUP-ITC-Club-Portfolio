<html>
<head>

</head>
<body>
<h1>Hello evge</h1>
</body>
</html><?php /**PATH D:\setup\server\www\DUCCportfolio\resources\views/admin/meeting_mail.blade.php ENDPATH**/ ?>