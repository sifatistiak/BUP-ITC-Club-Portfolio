
<footer class="footer text-right">
    2019 © Developed by <a href="http://skoder.co" target="_blank">skoder.co</a>
</footer>
<?php /**PATH D:\setup\server\www\DUCCportfolio\resources\views/includes/admin_footer.blade.php ENDPATH**/ ?>