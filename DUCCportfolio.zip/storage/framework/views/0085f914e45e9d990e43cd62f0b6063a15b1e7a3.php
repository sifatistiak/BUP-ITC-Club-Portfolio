<?php $__env->startSection('title','Achievement'); ?>

<?php $__env->startSection('content'); ?>
    <div class="single-service-area ptb-100">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-lg-9 col-xs-12">
                    <div class="single-service-wrap">
                            <div class="single-service-img">
                                <img src="<?php echo e(asset('single_achievement_images/'.$achievement->image)); ?>" alt="">
                            </div><br><br>
                        <h3><?php echo e($achievement->title); ?></h3>
                        <p><?php echo e($achievement->desc); ?></p>
                        <p><?php echo app('translator')->getFromJson('header.Achievement Date'); ?> - <?php echo e($achievement->achievement_date->format('d M Y')); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\setup\server\www\DUCCportfolio\resources\views/frontend/single_achievement.blade.php ENDPATH**/ ?>