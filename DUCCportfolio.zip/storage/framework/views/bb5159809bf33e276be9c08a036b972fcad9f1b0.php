<?php echo e($slot); ?>

<?php /**PATH D:\setup\server\www\DUCCportfolio\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>