<?php $__env->startSection('title','Admin Change Password'); ?>
<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="col-md-6">

    <div class="card">
        <div class="card-header"><h3><?php echo e(__('Change Password')); ?></h3></div><br><br>
        <div class="card-body">
            <div class="alert alert-danger" id="error" style="display: none"></div>
            <form method="POST" id="change-password-form" action="<?php echo e(route('admin.change.password')); ?>">
                <?php echo csrf_field(); ?>


                <div class="form-group row">
                    <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Old Password')); ?></label>

                    <div class="col-md-6">
                        <input id="oldpassword" type="password" name="oldpassword" required>

                    </div>
                </div>

                <div class="form-group row">
                    <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('New Password')); ?></label>

                    <div class="col-md-6">
                        <input id="password" type="password" name="password" required>

                    </div>
                </div>

                <div class="form-group row">
                    <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm New Password')); ?></label>

                    <div class="col-md-6">
                        <input id="password-confirm" type="password" name="password_confirmation" required>

                    </div>
                </div>

                <div class="form-group row mb-0">
                    <div class="col-md-8 offset-md-4">
                        <button type="submit" class="btn btn-primary">
                            <?php echo e(__('Change Password')); ?>

                        </button>

                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

    
        
            
            
            
            
            
                
                
                
                
                
                    
                    
                        
                         
                        

                    
                        
                        
                        
                    

                
            
        
    

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\setup\server\www\DUCCportfolio\resources\views/admin/change_password.blade.php ENDPATH**/ ?>