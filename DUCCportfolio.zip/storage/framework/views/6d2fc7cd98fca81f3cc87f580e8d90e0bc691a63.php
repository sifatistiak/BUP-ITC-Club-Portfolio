<?php $__env->startSection('title','Members'); ?>
<?php $__env->startSection('content'); ?>


<!-- team-area start -->
<section class="team-area ptb-140">
<div class="container">
    <div class="row">

    </div>
    <div class="row">
        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12 col wow fadeInUp" data-wow-delay=".4s">
            <div class="team-wrap">
                <div class="team-img">
                    <img src="<?php echo e(asset('member_images/'.$member->image)); ?>" alt="" />
                </div>
                <div class="team-content">
                    <div class="team-info">
                        <h3><?php echo e($member->name); ?></h3>
                        <p><?php echo e(str_limit($member->biography)); ?></p>
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
           <br>
                <a href="<?php echo e(route('single.member',$member->id)); ?>" class="btn btn-success">Full info</a>
        </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
</section>
<!-- team-area end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\setup\server\www\DUCCportfolio\resources\views/frontend/members.blade.php ENDPATH**/ ?>