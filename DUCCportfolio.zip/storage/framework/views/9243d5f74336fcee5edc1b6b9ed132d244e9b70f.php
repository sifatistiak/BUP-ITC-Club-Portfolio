<?php $__env->startSection('title','DUCC'); ?>
<?php $__env->startSection('content'); ?>
    <!-- slider area start -->
    <section id="" class="slider-area">

        <div class="slider-active2 slider-next-prev-style">
            <div class="slider-items">
                <img src="<?php echo e(asset('frontend/assets/images/ducs/image034.jpg')); ?>" alt="" class="slider">
                <div class="slider-content text-center">
                    <div class="table">
                        <div class="table-cell">
                            <div class="container">
                                <div class="row">
                                    <div class="col-xs-12 col-md-8 col-md-offset-2">
                                        <h2><?php echo app('translator')->getFromJson('header.Dhaka University Cultural Club'); ?></h2>
                                        <p> ঢাকা বিশ্ববিদ্যালয়ের বিভিন্ন বিভাগ ও হলের শিক্ষার্থীদের সংস্কৃতিচর্চার একটি
                                            অভিন্ন প্ল্যাটফর্ম তৈরি এবং তাদের সাংস্কৃতিক প্রতিভাকে বিকশিত করার লক্ষ্যে
                                            ২০১৫ সালের ৫ই সেপ্টেম্বর কিছু স্বপ্নদ্রষ্টা মানুষের হাত ধরে জন্ম নেয় ‘ঢাকা
                                            বিশ্ববিদ্যালয় সাংস্কৃতিক সংসদ’ (ইংরেজিতে ‘Dhaka University Cultural Society’
                                            বা সংক্ষেপে DUCS)।</p>
                                        <ul>
                                            <li><a href="<?php echo e(route('be.a.member')); ?>"><?php echo app('translator')->getFromJson('header.Be a Member'); ?></a></li>
                                            <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson('header.Get Started'); ?></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="slider-items">
                <img src="<?php echo e(asset('frontend/assets/images/ducs/s4.jpg')); ?>" alt="" class="slider">
                <div class="slider-content text-center">
                    <div class="table">
                        <div class="table-cell">
                            <div class="container">
                                <div class="row">
                                    <div class="col-xs-12 col-md-8 col-md-offset-2">
                                        <h2><?php echo app('translator')->getFromJson('header.Dhaka University Cultural Club'); ?></h2>
                                        <p>ঢাকা বিশ্ববিদ্যালয়ের বিভিন্ন বিভাগ ও হলের শিক্ষার্থীদের সংস্কৃতিচর্চার একটি
                                            অভিন্ন প্ল্যাটফর্ম তৈরি এবং তাদের সাংস্কৃতিক প্রতিভাকে বিকশিত করার লক্ষ্যে
                                            ২০১৫ সালের ৫ই সেপ্টেম্বর কিছু স্বপ্নদ্রষ্টা মানুষের হাত ধরে জন্ম নেয় ‘ঢাকা
                                            বিশ্ববিদ্যালয় সাংস্কৃতিক সংসদ’ (ইংরেজিতে ‘Dhaka University Cultural Society’
                                            বা সংক্ষেপে DUCS)।</p>
                                        <ul>
                                            <li><a href="<?php echo e(route('be.a.member')); ?>"><?php echo app('translator')->getFromJson('header.Be a Member'); ?></a></li>
                                            <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson('header.Get Started'); ?></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- slider area end -->

    <!-- about-area start -->
    <section id="about" class="about-area ptb-140">
        <div class="container">
            <div class="row">
                
                
                
                
                
                <div class="col-md-6 col-xs-12 wow fadeInLeft">

                    <img src="<?php echo e(asset('frontend/assets/images/ducs/about.jpg')); ?>" alt=""/></div>
                <div class="col-md-6 col-xs-12 wow fadeInRight">
                    <div class="about-wrap">
                        <h2><?php echo app('translator')->getFromJson('header.who we are'); ?></h2>
                        <p><?php echo app('translator')->getFromJson('header.about'); ?></p>
                        <h2><?php echo app('translator')->getFromJson('header.Purpose of the organization'); ?></h2>
                        <ul>
                            <li><?php echo app('translator')->getFromJson('header.l1'); ?></li>
                            <li><?php echo app('translator')->getFromJson('header.l2'); ?></li>
                            <li><?php echo app('translator')->getFromJson('header.l3'); ?></li>
                            <li><?php echo app('translator')->getFromJson('header.l4'); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- about-area end -->

    <!-- .event-area start -->
    <section id="event" class="service-area pb-160">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12 wow fadeInUp">
                    <div class="section-title text-center">
                        <h2><?php echo app('translator')->getFromJson('header.Our Upcoming Events'); ?></h2>
                        <p><?php echo app('translator')->getFromJson('header.event desc'); ?></p>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $upcomingEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 col-sm-6 col-xs-12 col">
                        <div class="service-wrap mb-30">
                            <div class="service-img">
                                <img src="<?php echo e(asset('event_images/'.$event->image)); ?>" alt=""/>
                            </div>
                            <div class="service-content">
                                <h3><?php echo e($event->title); ?></h3>
                                <p><?php echo e(str_limit($event->desc,150)); ?></p>
                                <a href="<?php echo e(route('single.event',$event->id)); ?>"><?php echo app('translator')->getFromJson('header.Read More'); ?></a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section><br><br>

    <div class="featured-area pb-140">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12 wow fadeInUp">
                    <div class="section-title text-center">
                        <h2><?php echo app('translator')->getFromJson('header.Our Events'); ?></h2>
                        <p><?php echo app('translator')->getFromJson('header.events'); ?></p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="featured-wrap">
                        <ul>
                            <?php for($i = 0; $i<count($events); $i+=2): ?>
                                <li class="wow fadeInLeft" data-wow-delay=".1s">
                                    <a href="<?php echo e(route('single.event',$events[$i]->id)); ?>">
                                        <h3><?php echo e($events[$i]->event_date->format('d M Y')); ?></h3>
                                        <div class="featured-content">
                                            <div class="featured-img">
                                                <img src="<?php echo e(asset('event_images/'.$events[$i]->image)); ?>" alt=""/>

                                            </div>
                                            <div class="featured-info">
                                                <h4><?php echo e($events[$i]->title); ?></h4>
                                                <p><?php echo e(str_limit($events[$i]->desc,50)); ?></p>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <?php if($events[$i+1]): ?>
                                    <li class="wow fadeInLeft" data-wow-delay=".5s">
                                        <a href="<?php echo e(route('single.event',$events[$i+1]->id)); ?>">
                                            <h3><?php echo e($events[$i+1]->event_date->format('d M Y')); ?></h3>
                                            <div class="featured-content">
                                                <div class="featured-img">
                                                    <img src="<?php echo e(asset('event_images/'.$events[$i+1]->image)); ?>" alt=""/>
                                                </div>
                                                <div class="featured-info">

                                                    <h4><?php echo e($events[$i+1]->title); ?></h4>
                                                    <p><?php echo e(str_limit($events[$i+1]->desc,50)); ?></p>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            <?php endfor; ?>
                            <li>
                                <a href="<?php echo e(route('events')); ?>"><h3><?php echo app('translator')->getFromJson('header.View All'); ?></h3></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .event-area end -->
    <!-- fanfact-area start -->
    <section class="fanfact-area parallax black-opacity" data-speed="5"
             data-bg-image="<?php echo e(asset('frontend/assets/images/ducs/image030.jpg')); ?>">
        <div class="table">
            <div class="table-cell">
                <div class="container">

                </div>
            </div>
        </div>
    </section>
    <!-- fanfact-area end -->

    <!-- Achievement-area start -->
    <section id="achievements" class="porftolio-area ptb-70">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12 wow fadeInUp">
                    <div class="section-title text-center">
                        <h2><?php echo app('translator')->getFromJson('header.Our Achievement'); ?></h2>
                        <p><?php echo app('translator')->getFromJson('header.achievement desc'); ?></p>
                    </div>
                </div>
            </div>
            <div class="row grid">
                <?php $__currentLoopData = $achievements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achievement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 portfolio website col-sm-6 col-xs-12 col">
                        <div class="portfolio-wrap">
                            <div class="overlay">
                                <a href="<?php echo e(route('single.achievement',$achievement->id)); ?>">
                                    <i class="fa fa-link"></i>
                                </a>
                                <h3><?php echo e($achievement->title); ?></h3>
                                <p><?php echo e(str_limit($achievement->desc,50)); ?></p>
                            </div>
                            <div class="portfolio-img">
                                <img src="<?php echo e(asset('achievement_images/'.$achievement->image)); ?>" alt=""/>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-3"></div>
                <div class="col-md-3">
                    <a href="<?php echo e(route('achievements')); ?>" class="btn btn-primary"><?php echo app('translator')->getFromJson('header.View All'); ?></a>
                </div>
            </div>
        </div>
    </section>
    <!-- porftolio-area end -->

    <!-- notice-area start -->
    <section id="notice" class="service-area pb-160">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12 wow fadeInUp">
                    <div class="section-title text-center">
                        <h2><?php echo app('translator')->getFromJson('header.Notice Board'); ?></h2>
                        <p><?php echo app('translator')->getFromJson('header.notice'); ?></p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 col-sm-6 col-xs-12 col"></div>
                    <div class="col-md-4 col-sm-6 col-xs-12 col">
                        <div class="blog-wrap mb-30">
                            <div class="blog-img">
                                
                            </div>
                            <div class="blog-content">
                                <div class="blog-meta">

                                </div>
                                <?php if($notice): ?>
                                    <h3><a href="<?php echo e(route('single.notice',$notice->id)); ?>"><?php echo e($notice->title); ?></a></h3>
                                    <p><?php echo e(str_limit($notice->desc,300)); ?></p>

                                    <a href="<?php echo e(route('single.notice',$notice->id)); ?>"
                                       class="btn-style"><?php echo app('translator')->getFromJson('header.Read More'); ?></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12 col"></div>

            </div>
            <div class="row">
                <div class="col-md-4 col-sm-6 col-xs-12 col"></div>
                <div class="col-md-4 col-sm-6 col-xs-12 col">
                    <a href="<?php echo e(route('notices')); ?>" class="btn btn-primary"><?php echo app('translator')->getFromJson('header.View All'); ?></a>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12 col"></div>
            </div>
            <br>
        </div>
    </section>
    <!-- notice-area end -->

    <!-- video-area start -->
    <section class="video-area  parallax black-opacity wow fadeInUp" data-speed="5"
             data-bg-image="<?php echo e(asset('frontend/assets/images/ducs/image046.jpg')); ?>">
        <h2 class="hidden">Video area</h2>
        <div class="table">
            <div class="table-cell">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="video-wrap text-center">
                                <a href="https://www.youtube.com/watch?v=Qf-Pv6p0vWY" class="video-popup">
                                    <i class="fa fa-play"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- video-area end -->

    <!-- team-area start -->
    <section id="member" class="team-area ptb-140">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12 wow fadeInUp">
                    <div class="section-title text-center">
                        <h2><?php echo app('translator')->getFromJson('header.Members'); ?></h2>
                        <p><?php echo app('translator')->getFromJson('header.members desc'); ?></p>
                    </div>
                </div>
            </div>
            
            <div class="row">
                
                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 col wow fadeInUp" data-wow-delay=".4s">
                    <h3><?php echo app('translator')->getFromJson('header.principal advisor'); ?></h3>
                    <div class="team-wrap">
                        <div class="team-img">
                            <img src="<?php echo e(asset('member_images/image005.jpg')); ?>" alt=""/>
                        </div>
                        <div class="team-content">
                            <div class="team-info">
                                <h3><?php echo app('translator')->getFromJson('header.member name',['name'=>'অধ্যাপক ড. মো. আখতারুজ্জামান']); ?></h3>
                                <p><?php echo app('translator')->getFromJson('header.member desc',['desc'=>'উপাচার্য,ঢাকা বিশ্ববিদ্যালয়']); ?></p>

                            </div>
                        </div>
                    </div>
                    <br>
                </div>
                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 col wow fadeInUp" data-wow-delay=".4s">
                    <h3><?php echo app('translator')->getFromJson('header.moderator'); ?></h3>
                    <div class="team-wrap">
                        <div class="team-img">
                            <img src="<?php echo e(asset('member_images/image007.jpg')); ?>" alt=""/>
                        </div>
                        <div class="team-content">
                            <div class="team-info">
                                <h3><?php echo app('translator')->getFromJson('header.member name',['name'=>'সাবরিনা সুলতানা চৌধুরী']); ?></h3>
                                <p><?php echo app('translator')->getFromJson('header.member desc',['desc'=>'সহযোগী অধ্যাপক,গণযোগাযোগ ও সাংবাদিকতা বিভাগ, ঢাকা বিশ্ববিদ্যালয়']); ?></p>

                            </div>
                        </div>
                    </div>
                    <br>
                </div>
            </div>
            <br><br>
            
            <div class="row">
                <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12 wow fadeInUp">
                    <div class="section-title text-center">
                        <h2><?php echo app('translator')->getFromJson('header.teacher'); ?></h2>
                    </div>
                </div>
            </div>
            <br><br>
            <div class="row">
                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 col wow fadeInUp" data-wow-delay=".4s">
                    <div class="team-wrap">
                        <div class="team-img">
                            <img src="<?php echo e(asset('member_images/image009.jpg')); ?>" alt=""/>
                        </div>
                        <div class="team-content">
                            <div class="team-info">
                                <h3><?php echo app('translator')->getFromJson('header.member name',['name'=>'ড. সৌমিত্র শেখর']); ?></h3>
                                <p><?php echo app('translator')->getFromJson('header.member desc',['desc'=>'অধ্যাপক,বাংলা বিভাগ,ঢাকা িশ্ববিদ্যালয়']); ?></p>

                            </div>
                        </div>
                    </div>
                    <br>
                </div>


                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 col wow fadeInUp" data-wow-delay=".4s">
                    <div class="team-wrap">
                        <div class="team-img">
                            <img src="<?php echo e(asset('member_images/image011.jpg')); ?>" alt=""/>
                        </div>
                        <div class="team-content">
                            <div class="team-info">
                                <h3><?php echo app('translator')->getFromJson('header.member name',['name'=>'মফিজুর রহমান']); ?></h3>
                                <p><?php echo app('translator')->getFromJson('header.member desc',['desc'=>'অধ্যাপক,গণযোগাযোগ ও সাংবাদিকতা বিভাগ,ঢাকা বিশ্ববিদ্যালয়']); ?></p>
                            </div>
                        </div>
                    </div>
                    <br>
                </div>

                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 col wow fadeInUp" data-wow-delay=".4s">
                    <div class="team-wrap">
                        <div class="team-img">
                            <img src="<?php echo e(asset('member_images/image013.jpg')); ?>" alt=""/>
                        </div>
                        <div class="team-content">
                            <div class="team-info">
                                <h3><?php echo app('translator')->getFromJson('header.member name',['name'=>'সুদীপ চক্রবর্তী']); ?></h3>
                                <p><?php echo app('translator')->getFromJson('header.member desc',['desc'=>'সহকারী অধ্যাপক,থিয়েটার এন্ড পারফরমেন্স স্টাডিজবিভাগ, ঢাকা বিশ্ববিদ্যালয়']); ?></p>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <br><br>


            
            <div class="row">
                <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12 wow fadeInUp">
                    <div class="section-title text-center">
                        <h2><?php echo app('translator')->getFromJson('header.Advisor member'); ?></h2>
                    </div>
                </div>
            </div>
            <br><br>
            <div class="row">
                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 col wow fadeInUp" data-wow-delay=".4s">
                    <div class="team-wrap">
                        <div class="team-img">
                            <img src="<?php echo e(asset('member_images/image015.jpg')); ?>" alt=""/>
                        </div>
                        <div class="team-content">
                            <div class="team-info">
                                <h3><?php echo app('translator')->getFromJson('header.member name',['name'=>'জুনাইদ আহমেদ পলক']); ?></h3>
                                <p><?php echo app('translator')->getFromJson('header.member desc',['desc'=>'প্রতিমন্ত্রী, তথ্য ও যোগাযোগ প্রযুক্তি মন্ত্রণালয়,                                     গণপ্রজাতন্ত্রী বাংলাদেশ সরকার']); ?></p>

                            </div>
                        </div>
                    </div>
                    <br>
                </div>


                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 col wow fadeInUp" data-wow-delay=".4s">
                    <div class="team-wrap">
                        <div class="team-img">
                            <img src="<?php echo e(asset('member_images/image017.jpg')); ?>" alt=""/>
                        </div>
                        <div class="team-content">
                            <div class="team-info">
                                <h3><?php echo app('translator')->getFromJson('header.member name',['name'=>'লিয়াকত আলী লাকী']); ?></h3>
                                <p><?php echo app('translator')->getFromJson('header.member desc',['desc'=>'মহাপরিচালক,বাংলাদেশ শিল্পকলা একাডেমি']); ?></p>
                            </div>
                        </div>
                    </div>
                    <br>
                </div>


                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 col wow fadeInUp" data-wow-delay=".4s">
                    <div class="team-wrap">
                        <div class="team-img">
                            <img src="<?php echo e(asset('member_images/image019.jpg')); ?>" alt=""/>
                        </div>
                        <div class="team-content">
                            <div class="team-info">
                                <h3><?php echo app('translator')->getFromJson('header.member name',['name'=>'ফেরদৌস আহমেদ']); ?></h3>
                                <p><?php echo app('translator')->getFromJson('header.member desc',['desc'=>'চিত্রনায়ক']); ?></p>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="row">
                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 col wow fadeInUp" data-wow-delay=".4s">
                    <div class="team-wrap">
                        <div class="team-img">
                            <img src="<?php echo e(asset('member_images/image021.jpg')); ?>" alt=""/>
                        </div>
                        <div class="team-content">
                            <div class="team-info">
                                <h3><?php echo app('translator')->getFromJson('header.member name',['name'=>'প্রীত রেজা']); ?></h3>
                                <p><?php echo app('translator')->getFromJson('header.member desc',['desc'=>'চিত্রগ্রাহক']); ?></p>

                            </div>
                        </div>
                    </div>
                    <br>
                </div>


                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 col wow fadeInUp" data-wow-delay=".4s">
                    <div class="team-wrap">
                        <div class="team-img">
                            <img src="<?php echo e(asset('member_images/image023.jpg')); ?>" alt=""/>
                        </div>
                        <div class="team-content">
                            <div class="team-info">
                                <h3><?php echo app('translator')->getFromJson('header.member name',['name'=>'রাহুল আনন্দ']); ?></h3>
                                <p><?php echo app('translator')->getFromJson('header.member desc',['desc'=>'সঙ্গীতশিল্পী ও অভিনয়শিল্পী']); ?></p>
                            </div>
                        </div>
                    </div>
                    <br>
                </div>


                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 col wow fadeInUp" data-wow-delay=".4s">
                    <div class="team-wrap">
                        <div class="team-img">
                            <img src="<?php echo e(asset('member_images/image025.jpg')); ?>" alt=""/>
                        </div>
                        <div class="team-content">
                            <div class="team-info">
                                <h3><?php echo app('translator')->getFromJson('header.member name',['name'=>'ত্রপা মজুমদার']); ?></h3>
                                <p><?php echo app('translator')->getFromJson('header.member desc',['desc'=>'নাট্যকর্মী']); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <br><br>
            
            <div class="row">
                <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12 wow fadeInUp">
                    <div class="section-title text-center">
                        <h2><?php echo app('translator')->getFromJson('header.Other Members'); ?></h2>
                        
                    </div>
                </div>
            </div>
            <br><br>
            <div class="row">
                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12 col wow fadeInUp" data-wow-delay=".4s">
                        <div class="team-wrap">
                            <div class="team-img">
                                <img src="<?php echo e(asset('member_images/'.$member->image)); ?>" alt=""/>
                            </div>
                            <div class="team-content">
                                <div class="team-info">
                                    <h3><?php echo e($member->name); ?></h3>
                                    <p><?php echo e($member->designation); ?></p>

                                </div>
                            </div>
                        </div>
                        <br>
                        <a href="<?php echo e(route('single.member',$member->id)); ?>" class="btn btn-success">Full info</a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <br><br>
            <div class="row justify-content-center">
                <div class="col-md-3"></div>
                <div class="col-md-3"></div>
                <div class="col-md-3">
                    <a href="<?php echo e(route('members')); ?>" class="btn btn-primary"><?php echo app('translator')->getFromJson('header.View All'); ?></a>
                </div>
            </div>
        </div>

    </section>
    <!-- team-area end -->


    <!-- testmonial-area start -->
    <section id="testimonial" class="testmonial-area ptb-140">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12 wow fadeInUp">
                    <div class="section-title text-center">
                        <h2><?php echo app('translator')->getFromJson('header.Testimonial'); ?></h2>
                        <p><?php echo app('translator')->getFromJson('header.Testimonial desc'); ?></p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="test-active dotate-style">

                    <?php for($i = 0; $i<count($testimonials); $i+=2): ?>
                        <div class="col-xs-12 wow fadeInLeft">
                            <div class="client-wrap fix">
                                <div class="client-info text-right">
                                    <h3><?php echo e($testimonials[$i]->name); ?></h3>
                                    <span><?php echo e($testimonials[$i]->designation); ?></span>
                                    <ul>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star-o"></i></li>
                                    </ul>
                                    <p><?php echo e(str_limit($testimonials[$i]->desc,200)); ?></p>
                                </div>
                                <div class="client-img pull-right">
                                    <img
                                            src="<?php echo e(asset('testimonial_images/'.$testimonials[$i]->image)); ?>" alt=""/>
                                </div>
                            </div>
                        </div>

                        <?php if($testimonials[$i+1]): ?>
                            <div class="col-xs-12 wow fadeInRight">
                                <div class="client-wrap fix">
                                    <div class="client-info">
                                        <h3><?php echo e($testimonials[$i+1]->name); ?></h3>
                                        <span><?php echo e($testimonials[$i+1]->designation); ?></span>
                                        <ul>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                        </ul>
                                        <p><?php echo e(str_limit($testimonials[$i+1]->desc,200)); ?></p>
                                    </div>
                                    <div class="client-img pull-left client-img2">
                                        <img
                                                src="<?php echo e(asset('testimonial_images/'.$testimonials[$i+1]->image)); ?>"
                                                alt=""/>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endfor; ?>
                </div>
            </div>
        </div>
    </section>
    <!-- testmonial-area end -->

    <!-- praller-area start -->
    <section class="prallex-area black-opacity parallax ptb-180 wow fadeInUp" data-speed="3"
             data-bg-image="<?php echo e(asset('frontend/assets/images/ducs/image076.jpg')); ?>">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2 col-xs-12">
                    <div class="prallex-wrap text-center">
                        <h2><i class="fa fa-quote-left"></i><?php echo app('translator')->getFromJson('header.Dhaka University Cultural Club'); ?><i
                                    class="fa fa-quote-right"></i></h2>
                        <span><i class="fa fa-long-arrow-left"></i>  <i class="fa fa-long-arrow-right"></i></span>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- praller-area end -->

    <!-- blog-area start -->
    <section id="blog" class="blog-area ptb-140 bg-1">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12 wow fadeInUp">
                    <div class="section-title text-center">
                        <h2><?php echo app('translator')->getFromJson('header.Our Blog'); ?></h2>
                        <p><?php echo app('translator')->getFromJson('header.Blog Desc'); ?></p>
                    </div>
                </div>
            </div>

            <div class="row">
                <?php $__currentLoopData = $blogPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 col-sm-6 col-xs-12 col">
                        <div class="blog-wrap mb-30">
                            <div class="blog-img">
                                <img src="<?php echo e(asset('blog_images/'.$blogPost->image)); ?>" alt=""/>
                            </div>
                            <div class="blog-content">
                                <div class="blog-meta">

                                </div>
                                <h3><a href="<?php echo e(route('single.blog',$blogPost->id)); ?>"><?php echo e($blogPost->title); ?></a></h3>
                                <p><?php echo e(str_limit($blogPost->desc,200)); ?></p>
                                <a href="<?php echo e(route('single.blog',$blogPost->id)); ?>"
                                   class="btn-style"><?php echo app('translator')->getFromJson('header.Read More'); ?></a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-3"></div>
                <div class="col-md-3"></div>
                <div class="col-md-3">
                    <a href="<?php echo e(route('blog')); ?>" class="btn btn-primary"><?php echo app('translator')->getFromJson('header.View All'); ?></a>
                </div>
            </div>
        </div>
    </section>
    <!-- blog-area end -->

    <!-- newsletter-area start -->
    <section class="newsletter-area bg-img-1 black-opacity wow fadeInUp">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-xs-12">
                    <div class="newsletter-wrap">
                        <h2><?php echo app('translator')->getFromJson('header.Sign Up for DUCS'); ?></h2> <a class="btn btn-primary"
                                                                     href="<?php echo e(route('be.a.member')); ?>"><?php echo app('translator')->getFromJson('header.Be a Member'); ?></a><br>

                    </div>
                </div>
                <div class="col-md-6 col-xs-12">
                    <div class="newsletter-form form-style">

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- newsletter-area end -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\setup\server\www\DUCCportfolio\resources\views/frontend/index.blade.php ENDPATH**/ ?>