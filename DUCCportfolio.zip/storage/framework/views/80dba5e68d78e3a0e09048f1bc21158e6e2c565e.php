<?php $__env->startSection('title','Blog'); ?>

<?php $__env->startSection('content'); ?>

<!-- blog-details-area start -->
<section id="blog" class="blog-details-area ptb-140">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-xs-12">
                <div class="blog-details-wrap">

                    <div class="blog-details-content">
                        <h3><?php echo e($notice->title); ?></h3>
                        <p> <?php echo e($notice->desc); ?></p>
                        <p><?php echo app('translator')->getFromJson('header.Date'); ?>: <?php echo e($notice->date->format('d M Y')); ?></p>
                        <p><?php echo app('translator')->getFromJson('header.Posted By'); ?>   :  <?php echo e($notice->posted_by); ?></p>
                        <p><?php echo app('translator')->getFromJson('header.Notice From'); ?> :  <?php echo e($notice->notice_from); ?></p>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
<!-- blog-details-area end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\setup\server\www\DUCCportfolio\resources\views/frontend/single_notice.blade.php ENDPATH**/ ?>