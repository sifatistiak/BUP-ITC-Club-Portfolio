<?php $__env->startSection('title','Member'); ?>

<?php $__env->startSection('content'); ?>
    <div class="single-service-area ptb-100">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-lg-8 col-xs-12">
                    <div class="single-service-wrap">
                            <div class="single-service-img">
                                <img src="<?php echo e(asset('single_member_images/'.$member->image)); ?>" alt="">
                            </div><br><br>
                    </div>
                </div>
                <div class="col-md-4 col-lg-4 col-xs-12">
                    <h3>  <?php echo e($member->name); ?></h3>
                    <p>Email : <?php echo e($member->email); ?></p>
                    <p>Designation : <?php echo e($member->designation); ?></p>
                    <p>Phone : <?php echo e($member->phone); ?></p>
                    <p>Current Address : <?php echo e($member->current_address); ?></p>
                    <p>Permanent Address : <?php echo e($member->permanent_address); ?></p>
                    <p>Department : <?php echo e($member->department); ?></p>
                    <p>Biography : <?php echo e($member->biography); ?></p>
                    <p>Skills : <?php echo e($member->skills); ?></p>
                    <p>Achievement : <?php echo e($member->achievement); ?></p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\setup\server\www\DUCCportfolio\resources\views/frontend/single_member.blade.php ENDPATH**/ ?>