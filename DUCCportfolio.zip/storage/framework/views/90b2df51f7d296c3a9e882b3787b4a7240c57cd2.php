<?php $__env->startSection('title','Achievements'); ?>
<?php $__env->startSection('content'); ?>

<!-- porftolio-area start -->
<section class="porftolio-area ptb-100">
<div class="container">

    <div class="row grid">
        <?php $__currentLoopData = $achievements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achievement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 portfolio website col-sm-6 col-xs-12 col">
            <div class="portfolio-wrap">
                <div class="overlay">
                    <a  href="<?php echo e(route('single.achievement',$achievement->id)); ?>">
                        <i class="fa fa-link"></i>
                    </a>
                    <h3><?php echo e($achievement->title); ?></h3>
                    <p><?php echo e(str_limit($achievement->desc,50)); ?></p>
                </div>
                <div class="portfolio-img">
                    <img src="<?php echo e(asset('achievement_images/'.$achievement->image)); ?>" alt="" />
                </div>
            </div>
        </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="row ">
        <div class="col-md-3"></div>
        <div class="col-md-3"></div>
        <div class="col-md-3">
                <?php echo e($achievements->links()); ?>

        </div>
        <div class="col-md-3"></div>
    </div>
</div>
</section>
<!-- porftolio-area end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\setup\server\www\DUCCportfolio\resources\views/frontend/achievements.blade.php ENDPATH**/ ?>