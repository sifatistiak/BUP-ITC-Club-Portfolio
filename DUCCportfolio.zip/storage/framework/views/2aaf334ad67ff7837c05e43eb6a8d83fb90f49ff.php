<?php $__env->startSection('title','Events'); ?>
<?php $__env->startSection('content'); ?>

    <!-- .service-area start -->
<section class="service-area ptb-100">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-sm-6 col-xs-12 col">
                <div class="service-wrap mb-30">
                    <div class="service-img">
                        <img src="<?php echo e(asset('event_images/'.$event->image)); ?>" alt="" />
                    </div>
                    <div class="service-content">
                        <h3><?php echo e($event->title); ?></h3>
                        <p><?php echo e(str_limit($event->desc,150)); ?></p>
                        <a href="<?php echo e(route('single.event',$event->id)); ?>">Read More</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<!-- .service-area end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\setup\server\www\DUCCportfolio\resources\views/frontend/events.blade.php ENDPATH**/ ?>