<?php $__env->startSection('title','Blog'); ?>
<?php $__env->startSection('content'); ?>

<!-- .Blog-area start -->
<section class="blog-area ptb-140 bg-1">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $blogPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-sm-6 col-xs-12 col">
                <div class="blog-wrap mb-30">
                    <div class="blog-img">
                        <img src="<?php echo e(asset('blog_images/'.$blogPost->image)); ?>" alt="" />
                    </div>
                    <div class="blog-content">
                        <div class="blog-meta">

                        </div>
                        <h3><a href="<?php echo e(route('single.blog',$blogPost->id)); ?>"><?php echo e($blogPost->title); ?></a></h3>
                        <p><?php echo e(str_limit($blogPost->desc,200)); ?></p>
                        <a href="<?php echo e(route('single.blog',$blogPost->id)); ?>" class="btn-style">Read More</a>
                    </div>
                </div>
            </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-3"></div>
            <div class="col-md-3"></div>
            <div class="col-md-3">

        <?php echo e($blogPosts->links()); ?>

            </div>
        </div>

    </div>
</section>
<!-- .Blog-area end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\setup\server\www\DUCCportfolio\resources\views/frontend/blog.blade.php ENDPATH**/ ?>