<div class="row justify-content-center">
    <div class="col-md-6">
<?php if(count($errors)>0): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <?php echo e($error); ?>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-md-6">
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo session('success'); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo session('error'); ?>

            </div>
        <?php endif; ?>

    </div>
</div>
<?php /**PATH D:\setup\server\www\DUCCportfolio\resources\views/includes/message.blade.php ENDPATH**/ ?>