<div class="topbar">

    <!-- LOGO -->
    <div class="topbar-left">
        <a href="<?php echo e(route('admin.home')); ?>" class="logo"><span>DU<span>CC</span></span><i class="mdi mdi-layers"></i></a>
    </div>

    <!-- Button mobile view to collapse sidebar menu -->
    <div class="navbar navbar-default" role="navigation">
        <div class="container">

            <!-- Navbar-left -->
            <ul class="nav navbar-nav navbar-left">
                <li>
                    <button class="button-menu-mobile open-left waves-effect">
                        <i class="mdi mdi-menu"></i>
                    </button>
                </li>


            </ul>

            <!-- Right(Notification) -->
            <ul class="nav navbar-nav navbar-right">


                <li class="dropdown user-box">
                    <a href="" class="dropdown-toggle waves-effect user-link" data-toggle="dropdown"
                       aria-expanded="true">
                        <img src="<?php echo e(asset('admin/assets/images/users/avatar-1.jpg')); ?>" alt="user-img"
                             class="img-circle user-img">
                    </a>

                    <ul class="dropdown-menu dropdown-menu-right arrow-dropdown-menu arrow-menu-right user-list notify-list">
                        <li>
                            <h5>Hi, Admin</h5>
                        </li>

                        <li><a href="<?php echo e(route('admin.change.password.view')); ?>"><i class="ti-settings m-r-5"></i> Chnage Password</a></li>

                        <li><a href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><i class="ti-power-off m-r-5"></i> Logout</a></li>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>

                    </ul>
                </li>

            </ul> <!-- end navbar-right -->

        </div><!-- end container -->
    </div><!-- end navbar -->
</div>

<?php /**PATH D:\setup\server\www\DUCCportfolio\resources\views/includes/admin_top.blade.php ENDPATH**/ ?>